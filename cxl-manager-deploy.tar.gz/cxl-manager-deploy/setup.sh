#!/bin/bash

# Install dependencies
pip3 install -r requirements.txt

# Setup manager service
chmod +x scripts/setup_manager_service.sh
./scripts/setup_manager_service.sh

# Setup agent service
chmod +x scripts/setup_agent_service.sh
./scripts/setup_agent_service.sh

echo "Installation complete. Services are running."
